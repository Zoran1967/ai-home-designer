package com.zoran.aihomedesigner

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zoran.aihomedesigner.data.ImportedImage
import com.zoran.aihomedesigner.domain.Furniture
import com.zoran.aihomedesigner.domain.FurnitureLayoutValidator
import com.zoran.aihomedesigner.domain.Opening
import com.zoran.aihomedesigner.domain.PlanImage
import com.zoran.aihomedesigner.domain.Room
import com.zoran.aihomedesigner.ui.CalibrationScreen
import com.zoran.aihomedesigner.ui.CrashScreen
import com.zoran.aihomedesigner.ui.CreateProjectScreen
import com.zoran.aihomedesigner.ui.FurnitureFormScreen
import com.zoran.aihomedesigner.ui.FurnitureListScreen
import com.zoran.aihomedesigner.ui.OpeningFormScreen
import com.zoran.aihomedesigner.ui.OpeningListScreen
import com.zoran.aihomedesigner.ui.PlanScreen
import com.zoran.aihomedesigner.ui.Scene3DScreen
import com.zoran.aihomedesigner.ui.ProjectListScreen
import com.zoran.aihomedesigner.ui.ProjectsViewModel
import com.zoran.aihomedesigner.ui.RoomFormScreen
import com.zoran.aihomedesigner.ui.RoomListScreen
import kotlinx.coroutines.flow.flowOf

private enum class Screen {
    PROJECTS,
    CREATE_PROJECT,
    ROOMS,
    CREATE_ROOM,
    EDIT_ROOM,
    PLAN,
    SCENE3D,
    CALIBRATE,
    OPENINGS,
    CREATE_OPENING,
    EDIT_OPENING,
    FURNITURE,
    CREATE_FURNITURE,
    EDIT_FURNITURE
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    // Ako se aplikacija prošli put neočekivano zatvorila, prvo prikaži opis greške.
                    var crashReport by remember { mutableStateOf(CrashReporter.readPending(applicationContext)) }
                    val report = crashReport
                    if (report != null) {
                        CrashScreen(
                            report = report,
                            onContinue = {
                                CrashReporter.clear(applicationContext)
                                crashReport = null
                            }
                        )
                    } else {
                        AppRoot()
                    }
                }
            }
        }
    }
}

/** Čuva sliku koja čeka kalibraciju, da preživi okretanje ekrana. */
private val ImportedImageSaver = listSaver<ImportedImage?, Any>(
    save = { image ->
        if (image == null) emptyList() else listOf(image.fileName, image.widthPx, image.heightPx)
    },
    restore = { list ->
        if (list.size == 3) ImportedImage(list[0] as String, list[1] as Int, list[2] as Int) else null
    }
)

@Composable
private fun AppRoot(viewModel: ProjectsViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(Screen.PROJECTS) }
    var selectedProjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedRoomId by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedOpeningId by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedFurnitureId by rememberSaveable { mutableStateOf<String?>(null) }

    val projects by viewModel.projects.collectAsState()
    val selectedProject = projects?.firstOrNull { it.id == selectedProjectId }

    val context = LocalContext.current
    var pendingImage by rememberSaveable(stateSaver = ImportedImageSaver) {
        mutableStateOf<ImportedImage?>(null)
    }
    val planImageFlow = remember(selectedProjectId) {
        selectedProjectId?.let { viewModel.observePlanImage(it) } ?: flowOf<PlanImage?>(null)
    }
    val planImage by planImageFlow.collectAsState(initial = null)

    // Izbor slike plana iz galerije: slika se kopira u aplikaciju, pa ide na kalibraciju razmere.
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        val projectId = selectedProjectId
        if (uri != null && projectId != null) {
            viewModel.importPlanImage(projectId, uri) { imported ->
                if (imported != null) {
                    pendingImage = imported
                    screen = Screen.CALIBRATE
                } else {
                    Toast.makeText(context, R.string.plan_image_import_failed, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val roomsFlow = remember(selectedProjectId) {
        selectedProjectId?.let { viewModel.observeRooms(it) } ?: flowOf<List<Room>?>(null)
    }
    val rooms by roomsFlow.collectAsState(initial = null)
    val selectedRoom = rooms?.firstOrNull { it.id == selectedRoomId }

    // Otvori izabrane sobe (za ekran vrata i prozora) i svi otvori projekta (za plan).
    val roomOpeningsFlow = remember(selectedRoomId) {
        selectedRoomId?.let { viewModel.observeOpenings(it) } ?: flowOf<List<Opening>?>(null)
    }
    val roomOpenings by roomOpeningsFlow.collectAsState(initial = null)
    val openingToEdit = roomOpenings?.firstOrNull { it.id == selectedOpeningId }

    val roomFurnitureFlow = remember(selectedRoomId) {
        selectedRoomId?.let { viewModel.observeFurniture(it) } ?: flowOf<List<Furniture>?>(null)
    }
    val roomFurniture by roomFurnitureFlow.collectAsState(initial = null)
    val furnitureToEdit = roomFurniture?.firstOrNull { it.id == selectedFurnitureId }

    val projectOpeningsFlow = remember(selectedProjectId) {
        selectedProjectId?.let { viewModel.observeProjectOpenings(it) } ?: flowOf<List<Opening>?>(null)
    }
    val projectOpenings by projectOpeningsFlow.collectAsState(initial = null)

    val projectFurnitureFlow = remember(selectedProjectId) {
        selectedProjectId?.let { viewModel.observeProjectFurniture(it) } ?: flowOf<List<Furniture>?>(null)
    }
    val projectFurniture by projectFurnitureFlow.collectAsState(initial = null)

    BackHandler(enabled = screen != Screen.PROJECTS) {
        screen = when (screen) {
            Screen.CREATE_ROOM, Screen.EDIT_ROOM, Screen.PLAN, Screen.SCENE3D, Screen.OPENINGS, Screen.FURNITURE -> Screen.ROOMS
            Screen.CREATE_OPENING, Screen.EDIT_OPENING -> Screen.OPENINGS
            Screen.CREATE_FURNITURE, Screen.EDIT_FURNITURE -> Screen.FURNITURE
            else -> {
                selectedProjectId = null
                Screen.PROJECTS
            }
        }
    }

    // Odustajanje od kalibracije (dugme nazad) briše kopiju slike.
    BackHandler(enabled = screen == Screen.CALIBRATE) {
        pendingImage?.let { viewModel.discardImportedImage(it) }
        pendingImage = null
        screen = Screen.ROOMS
    }

    // Ako je izabrani projekat, soba ili otvor nestao (npr. obrisan), vrati se korak nazad.
    LaunchedEffect(
        projects, rooms, roomOpenings, roomFurniture, pendingImage,
        selectedProjectId, selectedRoomId, selectedOpeningId, selectedFurnitureId, screen
    ) {
        val needsProject = screen != Screen.PROJECTS && screen != Screen.CREATE_PROJECT
        val needsRoom = screen == Screen.EDIT_ROOM || screen == Screen.OPENINGS ||
            screen == Screen.CREATE_OPENING || screen == Screen.EDIT_OPENING ||
            screen == Screen.FURNITURE || screen == Screen.CREATE_FURNITURE || screen == Screen.EDIT_FURNITURE
        if (needsProject && projects != null && selectedProject == null) {
            selectedProjectId = null
            screen = Screen.PROJECTS
        } else if (needsRoom && rooms != null && selectedRoom == null) {
            screen = Screen.ROOMS
        } else if (screen == Screen.EDIT_OPENING && roomOpenings != null && openingToEdit == null) {
            screen = Screen.OPENINGS
        } else if (screen == Screen.EDIT_FURNITURE && roomFurniture != null && furnitureToEdit == null) {
            screen = Screen.FURNITURE
        } else if (screen == Screen.CALIBRATE && pendingImage == null) {
            screen = Screen.ROOMS
        }
    }

    when (screen) {
        Screen.PROJECTS -> ProjectListScreen(
            projects = projects,
            onNewProject = { screen = Screen.CREATE_PROJECT },
            onOpenProject = {
                selectedProjectId = it.id
                screen = Screen.ROOMS
            },
            onDeleteProject = { viewModel.deleteProject(it.id) }
        )

        Screen.CREATE_PROJECT -> CreateProjectScreen(
            onCreate = { name, type, onResult -> viewModel.createProject(name, type, onResult) },
            onDone = { screen = Screen.PROJECTS },
            onCancel = { screen = Screen.PROJECTS }
        )

        Screen.ROOMS -> selectedProject?.let { project ->
            RoomListScreen(
                projectName = project.name,
                rooms = rooms,
                onBack = {
                    selectedProjectId = null
                    screen = Screen.PROJECTS
                },
                onAddRoom = { screen = Screen.CREATE_ROOM },
                onOpenRoom = {
                    selectedRoomId = it.id
                    screen = Screen.EDIT_ROOM
                },
                onOpenPlan = { screen = Screen.PLAN },
                onOpenScene3D = { screen = Screen.SCENE3D },
                planImage = planImage,
                onImportPlanImage = { pickImage.launch("image/*") },
                onRemovePlanImage = { selectedProjectId?.let { viewModel.deletePlanImage(it) } },
                onOpenOpenings = {
                    selectedRoomId = it.id
                    screen = Screen.OPENINGS
                },
                onOpenFurniture = {
                    selectedRoomId = it.id
                    screen = Screen.FURNITURE
                },
                onDeleteRoom = { viewModel.deleteRoom(it.id) }
            )
        }

        Screen.CREATE_ROOM -> selectedProject?.let { project ->
            RoomFormScreen(
                initialRoom = null,
                onSubmit = { input, onResult -> viewModel.createRoom(project.id, input, onResult) },
                onDone = { screen = Screen.ROOMS },
                onCancel = { screen = Screen.ROOMS }
            )
        }

        Screen.EDIT_ROOM -> selectedRoom?.let { room ->
            RoomFormScreen(
                initialRoom = room,
                onSubmit = { input, onResult -> viewModel.updateRoom(room.id, input, onResult) },
                onDone = { screen = Screen.ROOMS },
                onCancel = { screen = Screen.ROOMS }
            )
        }

        Screen.PLAN -> selectedProject?.let { project ->
            PlanScreen(
                rooms = rooms,
                openings = projectOpenings.orEmpty(),
                furniture = projectFurniture.orEmpty(),
                onBack = { screen = Screen.ROOMS },
                onMoveRoom = { id, x, y -> viewModel.moveRoom(id, x, y) },
                onPlaceUnplaced = { viewModel.placeUnplacedRooms(project.id) },
                onMoveFurniture = { id, x, y, rotation -> viewModel.moveFurniture(id, x, y, rotation) }
            )
        }

        Screen.SCENE3D -> selectedProject?.let {
            Scene3DScreen(
                rooms = rooms,
                openings = projectOpenings.orEmpty(),
                furniture = projectFurniture.orEmpty(),
                onBack = { screen = Screen.ROOMS }
            )
        }

        Screen.OPENINGS -> selectedRoom?.let { room ->
            OpeningListScreen(
                room = room,
                openings = roomOpenings,
                onBack = { screen = Screen.ROOMS },
                onAdd = { screen = Screen.CREATE_OPENING },
                onOpen = {
                    selectedOpeningId = it.id
                    screen = Screen.EDIT_OPENING
                },
                onDelete = { viewModel.deleteOpening(it.id) }
            )
        }

        Screen.CREATE_OPENING -> selectedRoom?.let { room ->
            OpeningFormScreen(
                room = room,
                initialOpening = null,
                onSubmit = { input, onResult -> viewModel.createOpening(room.id, input, onResult) },
                onDone = { screen = Screen.OPENINGS },
                onCancel = { screen = Screen.OPENINGS }
            )
        }

        Screen.EDIT_OPENING -> {
            val room = selectedRoom
            val opening = openingToEdit
            if (room != null && opening != null) {
                OpeningFormScreen(
                    room = room,
                    initialOpening = opening,
                    onSubmit = { input, onResult -> viewModel.updateOpening(opening.id, input, onResult) },
                    onDone = { screen = Screen.OPENINGS },
                    onCancel = { screen = Screen.OPENINGS }
                )
            }
        }

        Screen.FURNITURE -> selectedRoom?.let { room ->
            FurnitureListScreen(
                room = room,
                furniture = roomFurniture,
                issues = FurnitureLayoutValidator.validate(
                    room,
                    roomFurniture.orEmpty(),
                    roomOpenings.orEmpty()
                ),
                onBack = { screen = Screen.ROOMS },
                onAdd = { screen = Screen.CREATE_FURNITURE },
                onOpen = {
                    selectedFurnitureId = it.id
                    screen = Screen.EDIT_FURNITURE
                },
                onDelete = { viewModel.deleteFurniture(it.id) }
            )
        }

        Screen.CREATE_FURNITURE -> selectedRoom?.let { room ->
            FurnitureFormScreen(
                room = room,
                initialFurniture = null,
                onSubmit = { input, onResult -> viewModel.createFurniture(room.id, input, onResult) },
                onDone = { screen = Screen.FURNITURE },
                onCancel = { screen = Screen.FURNITURE }
            )
        }

        Screen.EDIT_FURNITURE -> {
            val room = selectedRoom
            val item = furnitureToEdit
            if (room != null && item != null) {
                FurnitureFormScreen(
                    room = room,
                    initialFurniture = item,
                    onSubmit = { input, onResult -> viewModel.updateFurniture(item.id, input, onResult) },
                    onDone = { screen = Screen.FURNITURE },
                    onCancel = { screen = Screen.FURNITURE }
                )
            }
        }

        Screen.CALIBRATE -> {
            val image = pendingImage
            val projectId = selectedProjectId
            if (image != null && projectId != null) {
                CalibrationScreen(
                    image = image,
                    loadBitmap = { name, maxSide -> viewModel.loadPlanBitmap(name, maxSide) },
                    onSave = { metersPerPixel ->
                        viewModel.savePlanCalibration(projectId, image, metersPerPixel) {
                            pendingImage = null
                            screen = Screen.ROOMS
                        }
                    },
                    onCancel = {
                        viewModel.discardImportedImage(image)
                        pendingImage = null
                        screen = Screen.ROOMS
                    }
                )
            }
        }
    }
}
